# Landscape-specific farm management for insect biodiversity and ecosystem services – A review  

[Access this dataset on Dryad]  

This lit_review_data_and_code.zip file contains all data and code associated with the paper submitted to Ecology Letters, Effects of local management and landscape complexity on insects and ecosystem services in agroecosystems: A review of the intermediate landscape complexity hypothesis.  

# DATA & FILE OVERVIEW

lit_review_data_and_code.zip file  

|- lit_review_analysis_general.ipynb  
|- lit_review_interactions.Rmd  
|- Data/  
|  |- lit_review_data.csv  
|  |- lit_review_landscape_percents.csv   
|  |- landscape_inverted.csv  
|  |- Interaction_Analyses/  
|  |  |- lit_review_interactions.csv  
|  |  |- lit_review_recat_europe_for_analysis.csv  
|  |  |- lit_review_recat_for_analysis.csv  
|  |  |- lit_review_recat_na_for_analysis.csv  

# METHODOLOGICAL INFORMATION

### Description of methods used for collection/generation of data:  
* Data extracted from papers listed in Supporting Information Table S1. 

### Methods for processing the data: 
* All data analysis was done using the code in lit_review_analysis_general.ipynb and lit_review_interactions.Rmd.  

### Instrument- or software-specific information needed to interpret the data: 
* All analyses are done in Python (Version 3.11.5) and R, version 4.2.2 (R Core Team, 2022)  

  Python libraries  

  * pandas version v2.3.3  
  * numpy version v1.26.4  
  * seaborn version v0.13.2  
  * skimpy version v0.0.11  
  * matplotlib version v3.8.0  
  * scipy version v1.11.2  
  * statsmodels version v0.14.0  
  
  R libraries 
  
  * tidyverse v2.0.0  
  * dplyr v.1.1.4  
  * janitor v.2.2.1  
  * blme v.1.0.6  
  * lme4 v.1.1.36  

# DATA-SPECIFIC INFORMATION FOR: lit_review_data.csv
Data extracted from papers included in the review.  

* Number of variables: 16   
* Number of cases/rows: 651   
* Variable List:   
  * Title,  
  * Author,   
  * Year,   
  * Country,   
  * Continent,   
  * Response: Description of measured variable,   
  * Response Category: Natural enemies, pollinators, pests, crops, or arthropods,   
  * Response Type: Biodiversity or ecosystem services,   
  * Local Factor: Description of local management practice,   
  * Local Strategy: Reduced management intensity, floral resources, crop diversity, or structural modifications,   
  * Local Effect: Positive, negative, or non-significant response to local management,   
  * Radius: Size of measured area for landscape complexity,   
  * Minimum Complexity: Lowest measurement of complexity for the study,   
  * Maximum Complexity: Highest measurement of complexity for the study,   
  * Landscape Effect: Positive, negative, or non-significant response to landscape complexity,   
  * Interaction Effect: Positive, negative, or non-significant response to the interaction between local management and landscape complexity. 
* Missing data codes: NA

# DATA-SPECIFIC INFORMATION FOR: lit_review_landscape_percents.csv
* Number of variables: 10
* Number of cases/rows: 138
* Variable List: 
  * Title,
  * Author, 
  * Year, 
  * Simple Start: Low end of simple landscape category, 
  * Simple End: High end of simple landscape category, 
  * Int Start: Low end of intermediate landscape category, 
  * Int End: High end of intermediate landscape category, 
  * Complex Start: Low end of complex landscape category, 
  * Complex End: High end of complex landscape category, 
  * Metric: Way of measuring landscape complexity
* Missing data codes: NA

# DATA-SPECIFIC INFORMATION FOR: lit_review_landscape_percents.csv
* Number of variables: 5
* Number of cases/rows: 138
* Variable List: 
  * Title,
  * Author, 
  * Year, 
  * Metric: Way of measuring landscape complexity,
  * Inverted: Yes/No if a measure of landscape simplification was converted to complexity
* Missing data codes: NA

# DATA-SPECIFIC INFORMATION FOR: lit_review_interactions.csv
* Number of variables: 19
* Number of cases/rows: 95
* Variable List: 
  * Obs_ID, 
  * Title,
  * Author, 
  * Year, 
  * Response: Description of measured variable,   
  * Response Type: Biodiversity or ecosystem services, 
  * Response Category: Natural enemies, pollinators, pests, crops, or arthropods, 
  * Local Factor: Description of local management practice, 
  * Local Strategy: Reduced management intensity, floral resources, crop diversity, or structural modifications, 
  * Local Effect: Positive, negative, or non-significant response to local management, 
  * Landscape Gradient: Range of most to least complex landscape,
  * Landscape Effect: Positive, negative, or non-significant response to landscape complexity, 
  * Interaction Effect: Positive, negative, or non-significant response to the interaction between local management and landscape complexity, 
  * Simple Collapsed: Positive or non-positive responses of above observations in simple landscapes, 
  * Intermediate Collapsed: Positive or non-positive responses of above observations in intermediate landscapes, 
  * Complex Collapsed: Positive or non-positive responses of above observations in complex landscapes, 
  * Simple: Positive, negative, or non-significant responses of above observations in simple landscapes,
  * Intermediate: Positive, negative, or non-significant responses of above observations in intermediate landscapes, 
  * Complex: Positive, negative, or non-significant responses of above observations in complex landscapes  
* Missing data codes: NA

# DATA-SPECIFIC INFORMATION FOR: lit_review_recat_europe_for_analysis.csv, lit_review_recat_for_analysis.csv, lit_review_recat_na_for_analysis.csv
* Number of variables: 5
* Number of cases/rows: 60, 126, 57
* Variable List: 
  * Title,
  * Author, 
  * Year, 
  * Simple Pos: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Simple NS: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Simple Neg: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Intermediate Pos: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Intermediate NS: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Intermediate Neg: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Complex Pos: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Complex NS: 0 or 1 for not observed or observed response for this local/landscape pairing,  
  * Complex Neg: 0 or 1 for not observed or observed response for this local/landscape pairing,  
* Missing data codes: NA

# CODE/SOFTWARE

lit_review_analysis_general.ipynb: Contains code for Figures 1-3, Supporting Information Figures S1 and S2.  

lit_review_interactions.Rmd: Contains code for mixed-effects logistic regression models 1-4 (Table 3, Supporting Information Tables S2-5).  






